# Kadha AI

A Malayalam + English AI storytelling web app with Firebase backend and Capacitor Android packaging.

Read **SETUP.md** for complete Firebase setup, local run, Hosting deployment, and APK build instructions.

## Quick start

```bash
cp .env.example .env
# Fill .env from your Firebase Web app config
npm install
npm run dev
```

This is an integrated application source, not a preconfigured hosted service. Your Firebase project credentials and activation are required for cloud authentication, Firestore, and Gemini AI.
