# Kadha AI — Full-stack app setup

This repository contains the full web application source and a Capacitor Android wrapper. The app is wired to Firebase Authentication, Cloud Firestore, and Firebase AI Logic (Gemini). It uses browser speech recognition and speech synthesis for voice input/output; actual Malayalam voice availability depends on the user's browser/device speech engine.

## 1. Requirements

- Node.js 20.19+ or 22.12+
- Android Studio (latest stable) and Android SDK for APK builds
- A Google account and a Firebase project
- Chrome/Android Chrome recommended for speech recognition

## 2. Create and configure Firebase

1. Open https://console.firebase.google.com and create a project named `kadha-ai` (or another unique ID).
2. In **Project settings → General → Your apps**, add a Web app and copy its Firebase config.
3. Enable **Authentication → Sign-in method**:
   - Anonymous
   - Email/Password
   - Google (configure support email and OAuth consent as prompted)
4. Create a **Cloud Firestore** database in production mode.
5. In **Build → Firestore Database → Rules**, publish the included `firestore.rules`.
6. Open **Build → AI Logic** and enable the **Gemini Developer API** provider.
7. For production, configure Firebase App Check (reCAPTCHA Enterprise for web; Play Integrity for Android) and monitor usage/quotas.

### Configure local environment

Copy `.env.example` to `.env` and fill all six `VITE_FIREBASE_*` values from your Firebase web app config. Keep `.env` private and do not commit it. `VITE_GEMINI_MODEL` can be changed to a model currently enabled for your Firebase project.

The Firebase web config is an app identifier, not an admin credential. Never put service-account JSON or private server keys in a client app.

## 3. Run the website

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173). To create a production website bundle:

```bash
npm run build
```

## 4. Deploy website to Firebase Hosting

Install Firebase CLI and sign in:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy --only hosting,firestore:rules
```

The Hosting URL printed by Firebase is your live website. Add that domain to **Authentication → Settings → Authorized domains** if required.

## 5. Build Android APK

This project uses Capacitor to package the same responsive web app as an Android application.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio:
- Wait for Gradle sync.
- Set the app signing configuration for a release build.
- Select **Build → Generate Signed Bundle / APK → APK** for a release APK.
- For a quick local test, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`. Do not distribute a debug APK as a Play Store release.

For microphone permissions, add `RECORD_AUDIO` to `android/app/src/main/AndroidManifest.xml` if you use the native speech plugin or a WebView speech-recognition implementation that requires it. Android WebView speech recognition support varies by device; the current UI will fall back to typing when unsupported. For best voice input reliability inside the native app, integrate a maintained Capacitor speech-recognition plugin and request runtime microphone permission.

## 6. What's implemented

- Guest (anonymous Firebase Auth), email/password registration and sign-in, Google popup sign-in for web.
- Per-user Firestore character and story collections, with create/list/delete operations.
- Gemini story generation through Firebase AI Logic; Malayalam script and English prompts; character, setting, mood and length inputs.
- Story reading view, saved library, search and delete.
- Companion chat using Gemini multi-turn chat history in the current session.
- Browser microphone speech-to-text and device speech synthesis, with Malayalam `ml-IN` locale selection.
- Responsive web design and Capacitor Android wrapper.

## 7. Important production work before public launch

- Add a privacy policy URL and in-app links; describe AI processing, data retention and voice/microphone use.
- Implement account deletion and data export (including Firestore subcollections) before Play release.
- Add abuse/content reporting, age-appropriate safeguards, rate limiting and cost controls.
- Test guest-to-permanent-account linking so a guest can keep their stories after registration.
- Add Android native Google Sign-In (web popup is not the right production flow inside every Android WebView).
- Test Malayalam speech recognition/TTS on the exact Android devices and languages you intend to support.
- Add automated tests, crash reporting, App Check enforcement and Firestore rules tests.
- Review current Google Play Families/target audience requirements if the app is directed to children. Do not claim child-directed compliance without the required policy review.

## 8. Free-tier note

Firebase Spark/free quotas and Gemini Developer API free-tier availability/limits can change and vary by model, region and usage. AI, Firestore reads/writes, Hosting bandwidth, authentication providers and voice usage are not guaranteed unlimited or permanently zero-cost. Set budgets/alerts and verify current plan terms in Firebase Console before launch.
