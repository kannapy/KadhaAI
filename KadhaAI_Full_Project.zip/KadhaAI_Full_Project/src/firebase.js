import { initializeApp } from "firebase/app";
import {
  getAuth, onAuthStateChanged, signInAnonymously, GoogleAuthProvider,
  signInWithPopup, linkWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  EmailAuthProvider, linkWithCredential, signOut, updateProfile
} from "firebase/auth";
import {
  getFirestore, collection, addDoc, getDocs, doc, deleteDoc, updateDoc,
  serverTimestamp, query, orderBy, setDoc, getDoc
} from "firebase/firestore";
import { getAI, getGenerativeModel, GoogleAIBackend } from "firebase/ai";

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

export const configured = Boolean(config.apiKey && config.projectId && config.appId);
let app, auth, db, model;
if (configured) {
  app = initializeApp(config);
  auth = getAuth(app);
  db = getFirestore(app);
  try {
    const ai = getAI(app, { backend: new GoogleAIBackend() });
    model = getGenerativeModel(ai, { model: import.meta.env.VITE_GEMINI_MODEL || "gemini-3.8-flash" });
  } catch (e) {
    console.warn("Firebase AI Logic initialization:", e);
  }
}

export { auth, db };
export const observeAuth = (cb) => onAuthStateChanged(auth, cb);
export const guestLogin = () => signInAnonymously(auth);
export const googleLogin = () => auth.currentUser?.isAnonymous
  ? linkWithPopup(auth.currentUser, new GoogleAuthProvider())
  : signInWithPopup(auth, new GoogleAuthProvider());
export const emailRegister = async (email, password, displayName) => {
  const credential = EmailAuthProvider.credential(email, password);
  const result = auth.currentUser?.isAnonymous
    ? await linkWithCredential(auth.currentUser, credential)
    : await createUserWithEmailAndPassword(auth, email, password);
  if (displayName) await updateProfile(result.user, { displayName });
  return result;
};
export const emailLogin = (email, password) => signInWithEmailAndPassword(auth, email, password);
export const logout = () => signOut(auth);

function userCollection(uid, name) {
  if (!db || !uid) throw new Error("Connect Firebase and sign in first.");
  return collection(db, "users", uid, name);
}
export async function saveCharacter(uid, character) {
  return addDoc(userCollection(uid, "characters"), { ...character, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
}
export async function listCharacters(uid) {
  const snap = await getDocs(query(userCollection(uid, "characters"), orderBy("createdAt", "desc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
export async function removeCharacter(uid, id) {
  return deleteDoc(doc(db, "users", uid, "characters", id));
}
export async function saveStory(uid, story) {
  return addDoc(userCollection(uid, "stories"), { ...story, createdAt: serverTimestamp() });
}
export async function listStories(uid) {
  const snap = await getDocs(query(userCollection(uid, "stories"), orderBy("createdAt", "desc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
export async function removeStory(uid, id) {
  return deleteDoc(doc(db, "users", uid, "stories", id));
}
export async function generateWithGemini(prompt) {
  if (!model) throw new Error("Gemini is not connected. Enable Firebase AI Logic and check your Firebase configuration.");
  const result = await model.generateContent(prompt);
  return result.response.text();
}
export async function sendChat(history, message, language) {
  if (!model) throw new Error("Gemini is not connected. Enable Firebase AI Logic in Firebase Console.");
  const chat = model.startChat({
    history: history.slice(-12).map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.text }]
    }))
  });
  const langInstruction = language === "Malayalam"
    ? "Reply naturally in Malayalam. Keep the conversation warm, imaginative and age-appropriate."
    : "Reply in natural English. Keep the conversation warm, imaginative and age-appropriate.";
  const result = await chat.sendMessage(`${langInstruction}\nUser: ${message}`);
  return result.response.text();
}
