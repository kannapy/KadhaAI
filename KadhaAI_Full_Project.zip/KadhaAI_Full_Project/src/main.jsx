import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Sparkles, BookOpen, Users, MessageCircle, Mic, MicOff, Plus, Search,
  WandSparkles, Heart, Clock3, ChevronRight, Menu, X, LogIn, LogOut,
  UserRound, Trash2, Volume2, VolumeX, Send, Globe2, Feather, Library,
  Settings2, Check, AlertCircle, LoaderCircle, ArrowUpRight, Stars, Headphones,
  Languages, ShieldCheck
} from "lucide-react";
import {
  configured, observeAuth, guestLogin, googleLogin, emailRegister, emailLogin,
  logout, saveCharacter, listCharacters, removeCharacter, saveStory, listStories,
  removeStory, generateWithGemini, sendChat
} from "./firebase";
import "./styles.css";

const initialChat = {
  role: "assistant",
  text: "നമസ്കാരം! ഞാൻ നിങ്ങളുടെ കഥാസുഹൃത്താണ്. ഇന്ന് നമുക്ക് ഏത് ലോകത്തേക്കാണ് യാത്ര പോകേണ്ടത്?"
};
const moods = ["Magical", "Adventure", "Funny", "Mystery", "Heartwarming", "Fantasy"];
const languages = ["Malayalam", "English"];

function App() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [screen, setScreen] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const [language, setLanguage] = useState("Malayalam");
  const [characters, setCharacters] = useState([]);
  const [stories, setStories] = useState([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [activeStory, setActiveStory] = useState(null);
  const [search, setSearch] = useState("");
  const [chat, setChat] = useState([initialChat]);
  const [chatInput, setChatInput] = useState("");
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceAuto, setVoiceAuto] = useState(false);
  const recognitionRef = useRef(null);
  const chatEndRef = useRef(null);

  const [authMode, setAuthMode] = useState("signin");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");

  const [charName, setCharName] = useState("");
  const [charDescription, setCharDescription] = useState("");
  const [charTraits, setCharTraits] = useState("");
  const [charAge, setCharAge] = useState("");
  const [charRole, setCharRole] = useState("Hero");

  const [storyTitle, setStoryTitle] = useState("");
  const [storyPrompt, setStoryPrompt] = useState("");
  const [storyCharacter, setStoryCharacter] = useState("");
  const [storySetting, setStorySetting] = useState("A moonlit magical forest");
  const [storyMood, setStoryMood] = useState("Magical");
  const [storyLength, setStoryLength] = useState("Medium");
  const [storyLanguage, setStoryLanguage] = useState("Malayalam");

  useEffect(() => {
    if (!configured) { setAuthReady(true); return; }
    const unsub = observeAuth(u => { setUser(u); setAuthReady(true); });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) { setCharacters([]); setStories([]); return; }
    refreshLibrary();
  }, [user]);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [chat]);
  useEffect(() => { const handler = e => setScreen(e.detail); window.addEventListener("kadha:navigate", handler); return () => window.removeEventListener("kadha:navigate", handler); }, []);

  async function refreshLibrary() {
    try {
      const [c, s] = await Promise.all([listCharacters(user.uid), listStories(user.uid)]);
      setCharacters(c); setStories(s);
    } catch (e) { setNotice(e.message); }
  }

  async function enterGuest() {
    setBusy(true); setNotice("");
    try {
      if (!configured) throw new Error("Firebase isn't configured yet. Add your Firebase web config in the .env file first.");
      await guestLogin();
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      if (!configured) throw new Error("Add Firebase configuration to .env before signing in.");
      if (authMode === "register") await emailRegister(authEmail, authPassword, authName);
      else await emailLogin(authEmail, authPassword);
      setScreen("home");
    } catch (e) { setNotice(authError(e)); }
    finally { setBusy(false); }
  }

  async function googleSignIn() {
    setBusy(true); setNotice("");
    try {
      if (!configured) throw new Error("Add Firebase configuration to .env first.");
      await googleLogin();
      setScreen("home");
    } catch (e) { setNotice(authError(e)); }
    finally { setBusy(false); }
  }

  async function createCharacter(e) {
    e.preventDefault();
    if (!charName.trim()) return setNotice("Give your character a name first.");
    if (!user) return setNotice("Sign in or continue as guest to save characters.");
    setBusy(true); setNotice("");
    try {
      await saveCharacter(user.uid, {
        name: charName.trim(), description: charDescription.trim(),
        traits: charTraits.split(",").map(x => x.trim()).filter(Boolean),
        age: charAge.trim(), role: charRole
      });
      setCharName(""); setCharDescription(""); setCharTraits(""); setCharAge("");
      await refreshLibrary(); setScreen("characters"); setNotice("Character saved to your library.");
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }

  async function createStory(e) {
    e.preventDefault();
    if (!user) return setNotice("Sign in or continue as guest to create stories.");
    setBusy(true); setNotice(""); setActiveStory(null);
    const selected = characters.find(c => c.id === storyCharacter);
    const prompt = `You are Kadha AI, a creative and culturally sensitive storyteller.
Write an original, vivid, coherent ${storyLength.toLowerCase()}-length story in ${storyLanguage}.
Story title or idea: ${storyTitle || storyPrompt || "Create an imaginative new story"}.
Premise / user direction: ${storyPrompt || "Surprise me with an engaging plot"}.
Main character: ${selected ? `${selected.name}, ${selected.role}. ${selected.description}. Personality: ${(selected.traits || []).join(", ")}. Age: ${selected.age || "unspecified"}.` : "Invent a memorable protagonist."}
Setting: ${storySetting}. Mood: ${storyMood}.
If Malayalam is selected, write fluent natural Malayalam in Malayalam script, not transliteration. Use culturally natural names and expressions where appropriate.
Use a compelling opening, meaningful middle, satisfying ending, dialogue, and clear paragraphs. Keep it safe for a general audience. Do not include meta commentary.`;
    try {
      const text = await generateWithGemini(prompt);
      const story = {
        title: storyTitle.trim() || extractTitle(text) || "Untitled story",
        text, language: storyLanguage, mood: storyMood,
        characterId: storyCharacter || null, setting: storySetting,
        prompt: storyPrompt, length: storyLength
      };
      const ref = await saveStory(user.uid, story);
      const fullStory = { ...story, id: ref.id };
      setActiveStory(fullStory); setScreen("reader");
      await refreshLibrary();
    } catch (e) { setNotice(aiError(e)); }
    finally { setBusy(false); }
  }

  async function deleteChar(id) {
    if (!confirm("Delete this character?")) return;
    try { await removeCharacter(user.uid, id); await refreshLibrary(); }
    catch (e) { setNotice(e.message); }
  }
  async function deleteStory(id) {
    if (!confirm("Delete this story permanently?")) return;
    try {
      await removeStory(user.uid, id);
      if (activeStory?.id === id) setActiveStory(null);
      await refreshLibrary();
    } catch (e) { setNotice(e.message); }
  }

  function speak(text, lang = language) {
    if (!("speechSynthesis" in window)) return setNotice("Text-to-speech isn't supported in this browser.");
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === "Malayalam" ? "ml-IN" : "en-IN";
    utterance.rate = 0.92;
    utterance.onstart = () => setSpeaking(true);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => { setSpeaking(false); setNotice("This device may not have a Malayalam voice installed. Check your speech/voice settings."); };
    window.speechSynthesis.speak(utterance);
  }
  function stopSpeak() { window.speechSynthesis?.cancel(); setSpeaking(false); }

  function startListening() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return setNotice("Voice input isn't supported here. Try Chrome on Android or type your message.");
    const rec = new SpeechRecognition();
    setVoiceAuto(true);
    rec.lang = language === "Malayalam" ? "ml-IN" : "en-IN";
    rec.interimResults = false; rec.continuous = false;
    rec.onresult = e => {
      const transcript = e.results?.[0]?.[0]?.transcript || "";
      setChatInput(v => v ? `${v} ${transcript}` : transcript);
      setListening(false);
    };
    rec.onerror = e => { setListening(false); setNotice(`Microphone: ${e.error}. Check permission and try again.`); };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    try { rec.start(); setListening(true); } catch { setListening(false); }
  }
  function stopListening() { recognitionRef.current?.stop(); setListening(false); setVoiceAuto(false); }

  async function sendMessage(e) {
    e?.preventDefault();
    const message = chatInput.trim();
    if (!message || busy) return;
    if (!user) return setNotice("Sign in or continue as guest to chat with Kadha AI.");
    const next = [...chat, { role: "user", text: message }];
    setChat(next); setChatInput(""); setBusy(true); setNotice("");
    try {
      const reply = await sendChat(chat, message, language);
      setChat([...next, { role: "assistant", text: reply }]);
      if (voiceAuto) speak(reply, language);
      setVoiceAuto(false);
    } catch (e) { setVoiceAuto(false); setNotice(aiError(e)); }
    finally { setBusy(false); }
  }

  const filteredStories = stories.filter(s => `${s.title} ${s.text}`.toLowerCase().includes(search.toLowerCase()));
  const filteredChars = characters.filter(c => `${c.name} ${c.description}`.toLowerCase().includes(search.toLowerCase()));

  if (!authReady) return <div className="boot"><div className="brand-mark"><Sparkles/></div><p>Opening your story world…</p></div>;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
        <div className="brand" onClick={() => { setScreen("home"); setMenuOpen(false); }}>
          <div className="brand-mark"><Sparkles size={21}/></div>
          <div><strong>Kadha AI</strong><small>YOUR STORY. YOUR WORLD.</small></div>
          <button className="mobile-close" onClick={e => { e.stopPropagation(); setMenuOpen(false); }}><X/></button>
        </div>
        <div className="sidebar-label">WORKSPACE</div>
        <nav>
          <NavButton icon={<Sparkles/>} label="Discover" active={screen === "home"} onClick={() => nav("home")}/>
          <NavButton icon={<WandSparkles/>} label="Create a story" active={screen === "create"} onClick={() => nav("create")}/>
          <NavButton icon={<Users/>} label="My characters" active={screen === "characters" || screen === "new-character"} onClick={() => nav("characters")}/>
          <NavButton icon={<Library/>} label="Story library" active={screen === "library" || screen === "reader"} onClick={() => nav("library")}/>
          <NavButton icon={<MessageCircle/>} label="Voice companion" active={screen === "chat"} onClick={() => nav("chat")}/>
        </nav>
        <div className="sidebar-bottom">
          <div className="language-box">
            <div className="language-icon"><Globe2 size={17}/></div>
            <div><small>APP LANGUAGE</small><select value={language} onChange={e => setLanguage(e.target.value)}><option>Malayalam</option><option>English</option></select></div>
          </div>
          <div className="profile">
            <div className="avatar">{(user?.displayName || user?.email || "G").slice(0,1).toUpperCase()}</div>
            <div className="profile-meta"><strong>{user?.displayName || (user?.isAnonymous ? "Guest storyteller" : user?.email) || "Not signed in"}</strong><small>{user?.isAnonymous ? "Guest account" : user ? "Your account" : "Preview mode"}</small></div>
            {user ? <button className="icon-btn" title="Sign out" onClick={() => logout()}><LogOut size={16}/></button> : <button className="icon-btn" title="Sign in" onClick={() => nav("auth")}><LogIn size={16}/></button>}
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMenuOpen(true)}><Menu/></button>
          <div className="breadcrumb">Kadha AI <span>/</span> {screenLabel(screen)}</div>
          <div className="top-actions">
            <span className={`connection ${configured ? "connected" : "disconnected"}`}><i/> {configured ? "Firebase configured" : "Setup required"}</span>
            {!user ? <button className="top-login" onClick={() => setScreen("auth")}>Sign in <ArrowUpRight size={15}/></button> : <div className="top-avatar">{(user.displayName || user.email || "G").slice(0,1).toUpperCase()}</div>}
          </div>
        </header>

        {notice && <div className="notice"><AlertCircle size={17}/><span>{notice}</span><button onClick={() => setNotice("")}><X size={15}/></button></div>}

        {!configured && screen !== "auth" && <div className="setup-banner"><Settings2 size={18}/><div><b>Connect Firebase to activate Kadha AI</b><span>You're viewing the app shell. Add your Firebase web configuration and enable Authentication, Firestore and Firebase AI Logic.</span></div><button onClick={() => setScreen("auth")}>Setup guide</button></div>}

        {screen === "home" && <HomeScreen user={user} stories={stories} characters={characters} onCreate={() => setScreen("create")} onChat={() => setScreen("chat")} onLibrary={() => setScreen("library")} onCharacter={() => setScreen("new-character")} onOpenStory={s => { setActiveStory(s); setScreen("reader"); }}/>}
        {screen === "auth" && <AuthScreen mode={authMode} setMode={setAuthMode} name={authName} setName={setAuthName} email={authEmail} setEmail={setAuthEmail} password={authPassword} setPassword={setAuthPassword} onSubmit={submitAuth} onGoogle={googleSignIn} onGuest={enterGuest} busy={busy} configured={configured}/>}
        {screen === "create" && <CreateStory characters={characters} title={storyTitle} setTitle={setStoryTitle} prompt={storyPrompt} setPrompt={setStoryPrompt} character={storyCharacter} setCharacter={setStoryCharacter} setting={storySetting} setSetting={setStorySetting} mood={storyMood} setMood={setStoryMood} length={storyLength} setLength={setStoryLength} language={storyLanguage} setLanguage={setStoryLanguage} busy={busy} onSubmit={createStory} onNewCharacter={() => setScreen("new-character")}/>}
        {screen === "characters" && <Characters chars={filteredChars} search={search} setSearch={setSearch} onNew={() => setScreen("new-character")} onDelete={deleteChar}/>}
        {screen === "new-character" && <NewCharacter onSubmit={createCharacter} busy={busy} name={charName} setName={setCharName} description={charDescription} setDescription={setCharDescription} traits={charTraits} setTraits={setCharTraits} age={charAge} setAge={setCharAge} role={charRole} setRole={setCharRole}/>}
        {screen === "library" && <LibraryScreen stories={filteredStories} search={search} setSearch={setSearch} onOpen={s => { setActiveStory(s); setScreen("reader"); }} onDelete={deleteStory}/>}
        {screen === "reader" && activeStory && <StoryReader story={activeStory} onBack={() => setScreen("library")} onSpeak={s => speak(s, activeStory.language)} speaking={speaking} onStop={stopSpeak}/>}
        {screen === "chat" && <ChatScreen chat={chat} setChat={setChat} input={chatInput} setInput={setChatInput} onSend={sendMessage} onMic={listening ? stopListening : startListening} listening={listening} busy={busy} onSpeak={s => speak(s, language)} speaking={speaking} onStop={stopSpeak} endRef={chatEndRef} language={language} setLanguage={setLanguage}/>}
      </main>
    </div>
  );

  function nav(next) { setScreen(next); setMenuOpen(false); setSearch(""); }
}

function NavButton({ icon, label, active, onClick }) {
  return <button className={`nav-button ${active ? "active" : ""}`} onClick={onClick}>{icon}<span>{label}</span>{active && <i/>}</button>;
}

function HomeScreen({ user, stories, characters, onCreate, onChat, onLibrary, onCharacter, onOpenStory }) {
  return <div className="content home-content">
    <section className="hero">
      <div className="hero-orb orb-one"/><div className="hero-orb orb-two"/>
      <div className="hero-copy"><div className="eyebrow"><Stars size={14}/> A LITTLE MAGIC, A LOT OF IMAGINATION</div>
        <h1>Every great story<br/>starts with <em>you.</em></h1>
        <p>Create unforgettable worlds, build characters you love, and hear your stories come alive — in Malayalam or English.</p>
        <div className="hero-buttons"><button className="btn-primary" onClick={onCreate}>Create your story <ChevronRight size={17}/></button><button className="btn-ghost-light" onClick={onChat}><Mic size={16}/> Talk to Kadha</button></div>
      </div>
      <div className="hero-art"><div className="book-glow"/><div className="floating-star star-a">✦</div><div className="floating-star star-b">✧</div><div className="book-illustration"><div className="book-spine"/><div className="book-cover"><Sparkles size={42}/><span>Once<br/>upon a<br/><i>time…</i></span><small>KADHA AI</small></div></div><div className="orbit orbit-a"/><div className="orbit orbit-b"/></div>
      <div className="hero-foot"><span><span className="tiny-dot"/> Your imagination has no limits</span><span>✧ Made for curious minds</span></div>
    </section>
    <div className="section-heading"><div><div className="eyebrow dark">YOUR CREATIVE SPACE</div><h2>What shall we dream up?</h2></div><span className="muted">{user ? "Welcome back, storyteller" : "Explore as a guest"}</span></div>
    <div className="action-grid">
      <ActionCard icon={<WandSparkles/>} title="Create a story" desc="Turn a little idea into a whole new world." tint="lavender" onClick={onCreate} tag="AI STORYTELLER"/>
      <ActionCard icon={<Users/>} title="Build a character" desc="Dream up heroes, sidekicks and legends." tint="peach" onClick={onCharacter} tag="CHARACTER STUDIO"/>
      <ActionCard icon={<Headphones/>} title="Voice companion" desc="Chat, imagine and tell stories out loud." tint="blue" onClick={onChat} tag="TALK IT OUT"/>
    </div>
    <div className="section-heading lower"><div><div className="eyebrow dark">PICK UP WHERE YOU LEFT OFF</div><h2>Your story shelf</h2></div><button className="text-link" onClick={onLibrary}>View library <ArrowUpRight size={15}/></button></div>
    {stories.length ? <div className="story-grid">{stories.slice(0,3).map(s => <StoryCard key={s.id} story={s} onClick={() => onOpenStory(s)}/>)}</div> : <div className="empty-shelf"><div className="empty-icon"><BookOpen/></div><div><b>Your next favourite story is waiting.</b><span>Stories you create will appear here, ready whenever you are.</span></div><button className="btn-soft" onClick={onCreate}>Write the first one <ChevronRight size={15}/></button></div>}
    <div className="mini-stats"><div><Users/><b>{characters.length}</b><span>Characters</span></div><div><BookOpen/><b>{stories.length}</b><span>Stories saved</span></div><div><Languages/><b>2</b><span>Story languages</span></div><div><Heart/><b>∞</b><span>Possibilities</span></div></div>
  </div>;
}

function ActionCard({ icon, title, desc, tint, tag, onClick }) {
  return <button className="action-card" onClick={onClick}><div className={`action-icon ${tint}`}>{icon}</div><small>{tag}</small><b>{title}</b><span>{desc}</span><i><ArrowUpRight size={17}/></i></button>;
}
function StoryCard({ story, onClick }) {
  return <button className="story-card" onClick={onClick}><div className="story-card-art"><span className="story-art-spark">✦</span><BookOpen size={35}/><span className="story-art-bottom">{story.mood || "A NEW STORY"}</span></div><div className="story-card-copy"><small>{story.language || "Story"} · {story.mood || "Creative"}</small><b>{story.title}</b><span>{(story.text || "").slice(0,95)}…</span></div></button>;
}

function AuthScreen({ mode, setMode, name, setName, email, setEmail, password, setPassword, onSubmit, onGoogle, onGuest, busy, configured }) {
  return <div className="auth-wrap"><div className="auth-panel"><div className="auth-symbol"><Sparkles/></div><div className="eyebrow dark">YOUR STORY WORLD AWAITS</div><h1>{mode === "register" ? "Create your account." : "Welcome back."}</h1><p>Save your characters, keep every story, and pick up where imagination left off.</p>
    <div className="auth-tabs"><button className={mode === "signin" ? "selected" : ""} onClick={() => setMode("signin")}>Sign in</button><button className={mode === "register" ? "selected" : ""} onClick={() => setMode("register")}>Create account</button></div>
    <form onSubmit={onSubmit}>{mode === "register" && <label>Your name<input required value={name} onChange={e => setName(e.target.value)} placeholder="What should we call you?"/></label>}<label>Email address<input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input required minLength="6" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="btn-primary full" disabled={busy || !configured}>{busy ? <LoaderCircle className="spin"/> : null}{mode === "register" ? "Create account" : "Sign in"} <ChevronRight size={17}/></button></form>
    <div className="auth-divider"><span/>or continue with<span/></div><button className="google-btn" onClick={onGoogle} disabled={busy || !configured}><GoogleG/> Continue with Google</button><button className="guest-btn" onClick={onGuest} disabled={busy || !configured}><UserRound size={17}/> Continue as guest</button>
    {!configured && <div className="auth-warning"><AlertCircle size={16}/> Firebase setup is required to activate login. See SETUP.md in the project.</div>}
    <small className="auth-terms"><ShieldCheck size={13}/> Your stories are private to your account.</small>
  </div><div className="auth-aside"><div className="aside-stars">✦　✧　·　✦</div><div className="aside-book"><Sparkles/><span>Every world<br/>begins with<br/><i>one idea.</i></span></div><p>“A story is a door.<br/>Come on in.”</p></div></div>;
}
function GoogleG() { return <span className="google-g">G</span>; }

function CreateStory({ characters, title, setTitle, prompt, setPrompt, character, setCharacter, setting, setSetting, mood, setMood, length, setLength, language, setLanguage, busy, onSubmit, onNewCharacter }) {
  return <div className="content form-content"><div className="page-intro"><div className="eyebrow dark"><WandSparkles size={14}/> THE STORY STUDIO</div><h1>Let's make a little <em>magic.</em></h1><p>Give us a spark of an idea. Kadha AI will turn it into a story worth remembering.</p></div>
    <form className="builder-layout" onSubmit={onSubmit}><div className="builder-main">
      <div className="form-card"><div className="card-heading"><span className="step">01</span><div><b>The big idea</b><small>What should happen in your story?</small></div></div>
        <label>Story title <span className="optional">OPTIONAL</span><input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. The girl who collected moonlight"/></label>
        <label>Your story idea<textarea required value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="A young inventor discovers a tiny dragon living inside an old clock…" rows="5"/></label>
      </div>
      <div className="form-card"><div className="card-heading"><span className="step">02</span><div><b>Choose your character</b><small>Bring one of your saved characters along.</small></div></div>
        <select value={character} onChange={e => setCharacter(e.target.value)}><option value="">Create a new character for this story</option>{characters.map(c => <option key={c.id} value={c.id}>{c.name} — {c.role}</option>)}</select>
        {!characters.length && <button type="button" className="inline-create" onClick={onNewCharacter}><Plus size={15}/> Build your first character</button>}
        <label>Where does it happen?<input value={setting} onChange={e => setSetting(e.target.value)} placeholder="A moonlit magical forest"/></label>
      </div>
    </div><aside className="builder-side"><div className="form-card"><div className="card-heading"><span className="step">03</span><div><b>Set the feeling</b><small>Pick the flavour of your tale.</small></div></div>
      <label>Story mood</label><div className="choice-grid">{moods.map(m => <button type="button" key={m} className={`choice ${mood === m ? "chosen" : ""}`} onClick={() => setMood(m)}>{moodIcon(m)} {m}</button>)}</div>
      <label>Story language</label><div className="segmented">{languages.map(l => <button type="button" className={language === l ? "on" : ""} onClick={() => setLanguage(l)} key={l}>{l === "Malayalam" ? "മലയാളം" : "English"}</button>)}</div>
      <label>Story length</label><div className="segmented">{["Short","Medium","Long"].map(l => <button type="button" className={length === l ? "on" : ""} onClick={() => setLength(l)} key={l}>{l}</button>)}</div>
      <button className="btn-primary full generate-btn" disabled={busy}>{busy ? <><LoaderCircle className="spin"/> Weaving your story…</> : <><Sparkles size={17}/> Generate my story</>}</button>
      <small className="fine-print">AI stories can take a few seconds. Your story will be saved to your library.</small>
    </div></aside></form>
  </div>;
}

function NewCharacter({ onSubmit, busy, name, setName, description, setDescription, traits, setTraits, age, setAge, role, setRole }) {
  return <div className="content narrow"><div className="page-intro"><div className="eyebrow dark"><Users size={14}/> CHARACTER STUDIO</div><h1>Meet your next <em>legend.</em></h1><p>Make a character that feels real. You can bring them into any story.</p></div>
    <form className="form-card character-form" onSubmit={onSubmit}><div className="character-preview"><div className="character-avatar"><UserRound size={35}/></div><div><b>{name || "Your character"}</b><span>{role} · {age || "Age not set"}</span></div><span className="preview-badge">NEW CHARACTER</span></div>
      <label>Character name<input required value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Ananya"/></label>
      <div className="two-col"><label>Role<select value={role} onChange={e => setRole(e.target.value)}>{["Hero","Sidekick","Villain","Mentor","Friend","Magical creature","Other"].map(x => <option key={x}>{x}</option>)}</select></label><label>Age <span className="optional">OPTIONAL</span><input value={age} onChange={e => setAge(e.target.value)} placeholder="e.g. 16"/></label></div>
      <label>Who are they?<textarea required value={description} onChange={e => setDescription(e.target.value)} rows="4" placeholder="A curious, kind-hearted inventor who is afraid of thunderstorms…"/></label>
      <label>Personality traits <span className="optional">COMMA SEPARATED</span><input value={traits} onChange={e => setTraits(e.target.value)} placeholder="Brave, curious, funny, loyal"/></label>
      <button className="btn-primary full" disabled={busy}>{busy ? <LoaderCircle className="spin"/> : <><Check size={17}/> Save character</>}</button>
    </form>
  </div>;
}

function Characters({ chars, search, setSearch, onNew, onDelete }) {
  return <div className="content"><div className="page-top"><div><div className="eyebrow dark">CHARACTER STUDIO</div><h1>Your cast of <em>characters.</em></h1><p>Every great story needs someone worth rooting for.</p></div><button className="btn-primary" onClick={onNew}><Plus size={17}/> New character</button></div>
    <SearchBar value={search} onChange={setSearch} placeholder="Find a character…"/>
    {chars.length ? <div className="character-grid">{chars.map(c => <div className="character-card" key={c.id}><div className="character-card-top"><div className="character-avatar"><UserRound/></div><span>{c.role}</span><button className="icon-btn danger" onClick={() => onDelete(c.id)}><Trash2 size={16}/></button></div><h3>{c.name}</h3><p>{c.description}</p><div className="trait-list">{(c.traits || []).map(t => <span key={t}>{t}</span>)}</div></div>)}</div> : <EmptyState icon={<Users/>} title="Your cast is waiting." desc="Create your first character and bring them into a story." action="Create a character" onClick={onNew}/>}
  </div>;
}
function LibraryScreen({ stories, search, setSearch, onOpen, onDelete }) {
  return <div className="content"><div className="page-top"><div><div className="eyebrow dark">YOUR STORY COLLECTION</div><h1>The story <em>shelf.</em></h1><p>Every world you've created, all in one place.</p></div></div><SearchBar value={search} onChange={setSearch} placeholder="Search your stories…"/>
    {stories.length ? <div className="story-grid library-grid">{stories.map(s => <div className="story-item" key={s.id}><StoryCard story={s} onClick={() => onOpen(s)}/><button className="delete-story" onClick={() => onDelete(s.id)} title="Delete story"><Trash2 size={15}/></button></div>)}</div> : <EmptyState icon={<BookOpen/>} title="A shelf full of possibilities." desc="Your generated stories will be saved here." action="Create your first story" onClick={() => window.dispatchEvent(new CustomEvent("kadha:navigate", { detail: "create" }))}/>}
  </div>;
}
function StoryReader({ story, onBack, onSpeak, speaking, onStop }) {
  return <div className="content reader-content"><button className="back-link" onClick={onBack}>← Back to your library</button><article className="story-paper"><div className="paper-top"><span>{story.language} · {story.mood}</span><span><Feather size={14}/> A KADHA AI ORIGINAL</span></div><h1>{story.title}</h1><div className="paper-actions"><button className="btn-soft" onClick={() => speaking ? onStop() : onSpeak(story.text)}>{speaking ? <VolumeX size={16}/> : <Volume2 size={16}/>} {speaking ? "Stop reading" : "Listen to story"}</button><span><Clock3 size={14}/> Your saved story</span></div><div className={`story-body ${story.language === "Malayalam" ? "malayalam" : ""}`}>{story.text.split(/\n{2,}/).map((p,i) => <p key={i}>{p}</p>)}</div><div className="paper-end">✦　THE END　✦</div></article></div>;
}
function ChatScreen({ chat, setChat, input, setInput, onSend, onMic, listening, busy, onSpeak, speaking, onStop, endRef, language, setLanguage }) {
  return <div className="content chat-content"><div className="chat-heading"><div><div className="eyebrow dark"><MessageCircle size={14}/> YOUR STORY COMPANION</div><h1>Let's talk <em>stories.</em></h1><p>Ask for a plot twist, dream up a new character, or just start with “once upon a time”.</p></div><div className="companion-orb"><Sparkles size={27}/><i/></div></div>
    <div className="chat-panel"><div className="chat-panel-head"><div className="online-dot"/><div><b>Kadha, your story friend</b><small>Ready to imagine with you</small></div><select value={language} onChange={e => setLanguage(e.target.value)}><option>Malayalam</option><option>English</option></select></div>
      <div className="chat-messages">{chat.map((m,i) => <div key={i} className={`message-row ${m.role === "user" ? "mine" : ""}`}><div className="message-avatar">{m.role === "user" ? <UserRound size={16}/> : <Sparkles size={16}/>}</div><div className="message-bubble"><p>{m.text}</p>{m.role === "assistant" && <button className="message-speak" onClick={() => speaking ? onStop() : onSpeak(m.text)}>{speaking ? <VolumeX size={14}/> : <Volume2 size={14}/>} Listen</button>}</div></div>)}{busy && <div className="typing"><i/><i/><i/> Kadha is thinking…</div>}<div ref={endRef}/></div>
      <form className="chat-compose" onSubmit={onSend}><button type="button" className={`mic-button ${listening ? "listening" : ""}`} onClick={onMic} title={listening ? "Stop listening" : "Speak"}>{listening ? <MicOff/> : <Mic/>}</button><input value={input} onChange={e => setInput(e.target.value)} placeholder={listening ? "Listening… speak now" : "Type in Malayalam or English…"} /><button className="send-button" disabled={!input.trim() || busy}><Send size={17}/></button></form>
      <div className="chat-foot"><ShieldCheck size={13}/> Voice input uses your browser's speech recognition. Microphone permission is required.</div>
    </div>
  </div>;
}
function SearchBar({ value, onChange, placeholder }) { return <div className="search-bar"><Search size={17}/><input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}/></div>; }
function EmptyState({ icon, title, desc, action, onClick }) { return <div className="empty-state"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{desc}</p><button className="btn-primary" onClick={onClick}>{action} <ChevronRight size={16}/></button></div>; }
function moodIcon(m) { return ({Magical:"✧",Adventure:"⚑",Funny:"☻",Mystery:"◈",Heartwarming:"♡",Fantasy:"✦"})[m] || "✧"; }
function screenLabel(s) { return ({home:"Discover",auth:"Account",create:"Story studio",characters:"Characters","new-character":"New character",library:"Story library",reader:"Reading room",chat:"Voice companion"})[s] || "Discover"; }
function extractTitle(t) { return t.split("\n").find(x => x.trim().length > 2 && x.trim().length < 90)?.replace(/^#+\s*/,""); }
function authError(e) { return e.code === "auth/unauthorized-domain" ? "Add this website domain to Firebase Authentication > Settings > Authorized domains." : e.message; }
function aiError(e) { return e.code === "permission-denied" ? "Firebase AI Logic access was denied. Enable the Gemini Developer API in Firebase Console and check App Check / API restrictions." : e.message; }

createRoot(document.getElementById("root")).render(<App/>);
